package com.example.szachownica;

import android.app.Notification;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import static java.lang.Math.min;


public class MainActivity extends AppCompatActivity {

    Panel panel;
    Paint tlo_pan = new Paint();
    Paint tlo_pan2 = new Paint();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(panel = new Panel(this));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.autor) {
            Context ctx = getApplicationContext();
            CharSequence txt = "Twórca: Jan Białek";
            int time = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(ctx, txt, time);
            toast.setGravity(Gravity.BOTTOM, 0, 0);
            toast.show();
            return true;
        } else if (itemId == R.id.exit) {
            finish();
            return true;
        } else if (itemId == R.id.kolorystyka1) {
            tlo_pan.setColor(Color.BLACK);
            tlo_pan2.setColor(Color.WHITE);
            panel.postInvalidate();
            return true;

        } else if (itemId == R.id.kolorystyka2) {
            tlo_pan.setColor(Color.RED);
            tlo_pan2.setColor(Color.YELLOW);
            panel.postInvalidate();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
}


class Panel extends View {
    Panel panel;
    Paint tlo_pan = new Paint();
    Paint tlo_pan2 = new Paint();

    public Panel(Context ctx) {
        super(ctx);
        tlo_pan.setColor(Color.WHITE);
        tlo_pan2.setColor(Color.BLACK);
    }

    public void onDraw(Canvas cv) {
        cv.drawColor(Color.GRAY);

        float wid = panel.getWidth();
        float hei = panel.getHeight();

        float size = Math.min(wid, hei);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                float left = i * size / 8;
                float top = j * size / 8;
                float right = (i + 1) * size / 8;
                float bottom = (j + 1) * size / 8;

                if ((i + j) % 2 == 0) {
                    cv.drawRect(left, top, right, bottom, tlo_pan);
                } else {
                    cv.drawRect(left, top, right, bottom, tlo_pan2);
                }
            }
        }
    }
}
